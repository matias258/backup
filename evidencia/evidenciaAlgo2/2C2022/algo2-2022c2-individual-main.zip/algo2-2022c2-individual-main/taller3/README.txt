En esta carpeta debe ubicarse el contenido del taller 3.
